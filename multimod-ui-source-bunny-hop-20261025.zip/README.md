# MultiMod UI Source

This source bundle accompanies the MultiMod UI asset pack: the CS2Menus layouts,
styles and icons, plus the versioned Superpowers reveals. It is not
a playable map or the source of the server-side MultiMod/native plugins.

Local Superpowers reveal additions and integration: Bulqe. See NOTICE.md and
UPSTREAM.md for original project credits. LICENSE contains the unchanged GNU
Affero General Public License, version 3. Existing third-party notices remain.

## Contents

- `ui/`: exact editable sources from the verified release, including addoninfo.txt,
  the Panorama preprocessor configuration and XML/CSS/SVG resources. Exact counts
  and the included reveal versions are recorded in SOURCE-MANIFEST.json.
- `ui/tools/`: the four upstream layout/style/icon generators and minifier.
- `BUILD.ps1`: Windows-only compilation using your installed CS2 Workshop Tools.
- `SOURCE-MANIFEST.json`: relative filenames, checksums and source-to-resource
  correspondence. Hashes describe this snapshot; they are not a signature.

There are no credentials, private server settings, player records, deployment
scripts, compiled server binaries, debug symbols or game archives in this bundle.
The cover image is separate and is not licensed by this UI source bundle.

## Build

Install Counter-Strike 2 and its Workshop Tools through Steam. Choose a new local
build folder outside both this source folder and the game installation:

```powershell
./BUILD.ps1 -Cs2Root '<your-CS2-installation>' -OutputDirectory '<new-build-folder>'
```

The script copies sources to a fresh content tree, compiles with resourcecompiler,
checks that each expected compiled resource exists and preserves installed
gameinfo.gi. It does not publish, connect to a server, install plugins or modify
your existing addons. Temporary build junctions are removed non-recursively.
Do not redistribute build logs/gameinfo: generated build paths can identify your
local installation. Share reviewed source and compiled assets instead.

The included editable sources are the matching inputs for this release. Normal
compilation does not rerun generators. In a working copy, `ui/tools/gen_layouts.py`
regenerates repeated layouts; it can overwrite local layout customizations.
`gen_econ_images.py` and `gen_tints.py` additionally require the Python `vpk` module
and an installed game's pak01_dir.vpk. They regenerate economy styles/icons and
tint data when the game changes. `minify.py` can create a separate minimized copy;
keep the preferred editable sources as well. Dependencies/game tools are not
redistributed or automatically installed here.

Rebuilding is not proof that the paired server renderer works. Native rendering,
power assignment and client downloads require separate acceptance checks.
