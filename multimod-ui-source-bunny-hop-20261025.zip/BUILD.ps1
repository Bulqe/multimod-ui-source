param(
    [Parameter(Mandatory)][string]$Cs2Root,
    [Parameter(Mandatory)][string]$OutputDirectory
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
function LocalPath([string]$Path) {
    if (!$Path -or $Path.StartsWith('\\') -or $Path.StartsWith('//')) { throw 'Use local paths only.' }
    $full = [IO.Path]::GetFullPath($Path).TrimEnd('\','/')
    if ($full.Substring(2).Contains(':')) { throw 'Device/stream paths are not supported.' }
    for ($cursor = $full; $cursor; $cursor = Split-Path $cursor -Parent) {
        if ((Test-Path -LiteralPath $cursor) -and ((Get-Item -LiteralPath $cursor -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)) {
            throw 'Use paths without reparse-point ancestors.'
        }
    }
    return $full
}
function Overlap([string]$A, [string]$B) {
    return $A.Equals($B,[StringComparison]::OrdinalIgnoreCase) -or
        $A.StartsWith($B+'\',[StringComparison]::OrdinalIgnoreCase) -or $B.StartsWith($A+'\',[StringComparison]::OrdinalIgnoreCase)
}
$Cs2Root = LocalPath $Cs2Root
$OutputDirectory = LocalPath $OutputDirectory
$source = LocalPath (Join-Path $PSScriptRoot 'ui')
if ((Overlap $OutputDirectory $PSScriptRoot) -or (Overlap $OutputDirectory $Cs2Root) -or (Test-Path -LiteralPath $OutputDirectory)) {
    throw 'Choose a fresh output folder outside the source and game installation.'
}
$compiler = Join-Path $Cs2Root 'game/bin/win64/resourcecompiler.exe'
$baseInfo = Join-Path $Cs2Root 'game/csgo/gameinfo.gi'
foreach ($required in @($compiler,$baseInfo,"$source/addoninfo.txt","$source/panorama/preprocessor_config.txt")) {
    if (!(Test-Path -LiteralPath $required -PathType Leaf)) { throw 'A required game tool or UI source is missing.' }
}
$baseHash = (Get-FileHash -LiteralPath $baseInfo).Hash
$content = Join-Path $OutputDirectory 'content/multimod_ui'
$game = Join-Path $OutputDirectory 'game/multimod_ui'
New-Item -ItemType Directory -Path $content,$game -Force | Out-Null
Copy-Item -LiteralPath "$source/panorama" -Destination $content -Recurse
Copy-Item -LiteralPath "$source/addoninfo.txt" -Destination $content
Copy-Item -LiteralPath "$source/addoninfo.txt" -Destination $game
$basePath = $baseInfo.Replace('\','/')
@"
#base "$basePath"
"GameInfo"
{
    game "MultiMod UI build"
    FileSystem { SearchPaths { Game "multimod_ui" Game "csgo" Game "core" Mod "multimod_ui" } }
}
"@ | Set-Content -LiteralPath "$game/gameinfo.gi" -Encoding ascii
$inputs = @(Get-ChildItem -LiteralPath "$content/panorama" -Recurse -File | Where-Object Extension -In '.xml','.css','.svg' | Sort-Object FullName)
$inputs.FullName | Set-Content -LiteralPath "$OutputDirectory/inputs.txt" -Encoding utf8
$created = [Collections.Generic.List[object]]::new()
try {
    foreach ($name in @('core','csgo')) {
        $target = LocalPath (Join-Path $Cs2Root "game/$name")
        if (!(Test-Path -LiteralPath $target -PathType Container)) { throw 'Game search-path folder missing.' }
        $link = Join-Path $OutputDirectory "game/$name"
        New-Item -ItemType Junction -Path $link -Target $target | Out-Null
        $created.Add(@{Path=$link;Target=$target})
    }
    $log = & $compiler -game $game -filelist "$OutputDirectory/inputs.txt" -f -nop4 -v 2>&1
    $exitCode = $LASTEXITCODE
    $log | Set-Content -LiteralPath "$OutputDirectory/compiler.log" -Encoding utf8
    if ($exitCode -ne 0) { throw 'Resource compilation failed; inspect your local compiler.log.' }
} finally {
    foreach ($item in $created) {
        $link = Get-Item -LiteralPath $item.Path -Force
        if ($link.LinkType -ne 'Junction' -or [IO.Path]::GetFullPath($link.Target) -ne $item.Target) { throw 'Unexpected build junction; refusing cleanup.' }
        [IO.Directory]::Delete($item.Path)
    }
    if ((Get-FileHash -LiteralPath $baseInfo).Hash -ne $baseHash) { throw 'Installed gameinfo changed during compilation.' }
}
foreach ($input in $inputs) {
    $extension = @{'.xml'='.vxml_c';'.css'='.vcss_c';'.svg'='.vsvg_c'}[$input.Extension.ToLowerInvariant()]
    $relative = [IO.Path]::ChangeExtension([IO.Path]::GetRelativePath($content,$input.FullName),$extension)
    $file = Get-Item -LiteralPath (Join-Path $game $relative)
    if ($file.Length -lt 32) { throw 'Compiled resource is empty or truncated.' }
}
"Compiled $($inputs.Count) UI resources. No publication or deployment performed."
