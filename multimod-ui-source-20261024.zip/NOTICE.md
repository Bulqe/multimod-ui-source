# Notices and Changes

The original CS2Menus Workshop assets and tools come from:
https://github.com/FemboyKZ/mm-cs2menus

The upstream Workshop README credits the menu layout's origin to the
cs2kz-metamod Workshop UI, by zer0.k:
https://github.com/KZGlobalTeam/cs2kz-metamod

Keep the original attribution and the unchanged AGPL-3.0 license. This bundle
does not relabel upstream work as exclusively authored by Bulqe.

Bulqe's local integration adds passive Superpowers reveal layouts/styles with
bounded client animation, authoritative result labels, and a separate cloak-aware
layout/version. The source-to-compiled-resource checksums identify the exact
snapshot supplied alongside this bundle.

Equipment icons and economy/tint data have the game-content origin described in
the upstream generators. No game executable, compiler or game archive is included.
These notices do not grant rights to third-party material beyond its applicable
terms. This UI-only bundle does not cover distribution of the separate server
plugins, nor does it claim completion of all license requirements for them.
